import io
import sys
import os
import numpy as np
import pytest
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import main as main_module


class FakeModel:
    """Stands in for the real Keras model so endpoint tests don't need
    TensorFlow to load an actual trained .h5 file."""

    def predict(self, x, verbose=0):
        # Always "confidently" predicts class index 2 (No Tumor)
        return np.array([[0.05, 0.05, 0.85, 0.05]], dtype=np.float32)


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setattr(main_module, "get_model", lambda: FakeModel())
    main_module.app.config["TESTING"] = True
    with main_module.app.test_client() as c:
        yield c


def _png_bytes():
    img = Image.new("L", (120, 120), color=100)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf


def test_index_page_loads(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert b"Neuro-Scan" in resp.data


def test_health_endpoint(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "ok"


def test_predict_missing_file_field(client):
    resp = client.post("/predict", data={})
    assert resp.status_code == 400
    assert "error" in resp.get_json()


def test_predict_empty_filename(client):
    data = {"file": (io.BytesIO(b""), "")}
    resp = client.post("/predict", content_type="multipart/form-data", data=data)
    assert resp.status_code == 400


def test_predict_unsupported_extension(client):
    data = {"file": (io.BytesIO(b"hello"), "notes.txt")}
    resp = client.post("/predict", content_type="multipart/form-data", data=data)
    assert resp.status_code == 400
    assert "Unsupported file type" in resp.get_json()["error"]


def test_predict_corrupt_image_bytes(client):
    data = {"file": (io.BytesIO(b"not a real image"), "scan.png")}
    resp = client.post("/predict", content_type="multipart/form-data", data=data)
    assert resp.status_code == 400


def test_predict_valid_image_returns_prediction(client):
    data = {"file": (_png_bytes(), "scan.png")}
    resp = client.post("/predict", content_type="multipart/form-data", data=data)
    assert resp.status_code == 200
    body = resp.get_json()
    assert body["predicted_class"] == "No Tumor"
    assert 0.0 <= body["confidence"] <= 1.0
    assert set(body["all_scores"].keys()) == {"Glioma", "Meningioma", "No Tumor", "Pituitary"}


def test_predict_returns_503_when_model_unavailable(monkeypatch):
    monkeypatch.setattr(main_module, "get_model", lambda: None)
    monkeypatch.setattr(main_module, "_model_load_error", "no model file found")
    main_module.app.config["TESTING"] = True
    with main_module.app.test_client() as c:
        data = {"file": (_png_bytes(), "scan.png")}
        resp = c.post("/predict", content_type="multipart/form-data", data=data)
        assert resp.status_code == 503
