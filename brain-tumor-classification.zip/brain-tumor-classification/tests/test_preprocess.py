import io
import numpy as np
import pytest
from PIL import Image

from src.preprocess import preprocess_image_bytes, allowed_file, InvalidImageError
from src.model_architecture import IMG_SIZE


def _png_bytes(size=(100, 100), mode="RGB"):
    img = Image.new(mode, size, color=128)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def test_allowed_file_accepts_known_extensions():
    for name in ["scan.png", "scan.JPG", "scan.jpeg", "scan.bmp", "scan.tiff"]:
        assert allowed_file(name)


def test_allowed_file_rejects_unknown_extensions():
    for name in ["scan.txt", "scan", "scan.exe", "scan.pdf"]:
        assert not allowed_file(name)


def test_preprocess_output_shape_and_range():
    arr = preprocess_image_bytes(_png_bytes())
    assert arr.shape == (1, IMG_SIZE, IMG_SIZE, 1)
    assert arr.dtype == np.float32
    assert arr.min() >= 0.0 and arr.max() <= 1.0


def test_preprocess_converts_rgb_to_grayscale():
    # A 3-channel image should still collapse to a single channel output
    arr = preprocess_image_bytes(_png_bytes(mode="RGB"))
    assert arr.shape[-1] == 1


def test_preprocess_handles_non_square_input():
    arr = preprocess_image_bytes(_png_bytes(size=(300, 150)))
    assert arr.shape == (1, IMG_SIZE, IMG_SIZE, 1)


def test_preprocess_rejects_empty_bytes():
    with pytest.raises(InvalidImageError):
        preprocess_image_bytes(b"")


def test_preprocess_rejects_corrupt_bytes():
    with pytest.raises(InvalidImageError):
        preprocess_image_bytes(b"not a real image")
