"""
Generates small synthetic grayscale images that stand in for real MRI scans.

These are NOT real MRI data (the actual Kaggle dataset is ~5,600 images and
isn't checked into the repo — see .gitignore). Their only purpose is to give
the test suite and the /predict endpoint something to exercise end-to-end
(upload -> preprocess -> shape/type checks) without requiring the dataset.

Run once:
    python test_samples/generate_samples.py
"""

import os
import numpy as np
from PIL import Image

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
SIZE = 200


def make_sample(name: str, seed: int):
    rng = np.random.default_rng(seed)
    arr = rng.integers(30, 220, size=(SIZE, SIZE), dtype=np.uint8)
    # crude circular "brain outline" so the sample isn't pure noise
    yy, xx = np.ogrid[:SIZE, :SIZE]
    center = SIZE // 2
    mask = (xx - center) ** 2 + (yy - center) ** 2 <= (center - 10) ** 2
    arr = np.where(mask, arr, 10).astype(np.uint8)
    Image.fromarray(arr, mode="L").save(os.path.join(OUT_DIR, f"{name}.png"))


def make_corrupt(name: str):
    """A file with an image extension but non-image bytes, for negative tests."""
    with open(os.path.join(OUT_DIR, f"{name}.png"), "wb") as f:
        f.write(b"this is not a real image file")


if __name__ == "__main__":
    make_sample("sample_scan_1", seed=1)
    make_sample("sample_scan_2", seed=2)
    make_corrupt("corrupt_file")
    print(f"Synthetic samples written to {OUT_DIR}")
