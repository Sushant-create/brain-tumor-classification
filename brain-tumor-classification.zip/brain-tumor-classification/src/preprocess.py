"""
Preprocessing utilities shared between training and inference.
Keeps the exact same resize / rescale / color-mode pipeline the model was
trained with, so predictions on new images are consistent.
"""

import io
import numpy as np
from PIL import Image, UnidentifiedImageError

from src.model_architecture import IMG_SIZE

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "bmp", "tif", "tiff"}


class InvalidImageError(ValueError):
    """Raised when an uploaded file is not a readable image."""


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def preprocess_image_bytes(file_bytes: bytes, img_size: int = IMG_SIZE) -> np.ndarray:
    """Convert raw uploaded bytes into a (1, img_size, img_size, 1) float32
    array scaled to [0, 1], matching the ImageDataGenerator(rescale=1./255)
    grayscale pipeline used during training.

    Raises InvalidImageError for empty/corrupt/unreadable files instead of
    letting PIL's low-level exception leak out.
    """
    if not file_bytes:
        raise InvalidImageError("Uploaded file is empty.")

    try:
        img = Image.open(io.BytesIO(file_bytes))
        img.load()
    except (UnidentifiedImageError, OSError) as exc:
        raise InvalidImageError(f"File could not be read as an image: {exc}") from exc

    img = img.convert("L")  # grayscale, matches color_mode='grayscale'
    img = img.resize((img_size, img_size))

    arr = np.asarray(img, dtype=np.float32) / 255.0
    arr = arr.reshape(1, img_size, img_size, 1)
    return arr
