"""
Model architecture for Brain Tumor MRI Classification.

This module defines a single build_model() function that is imported by
both train.py (training) and main.py (inference), so the architecture used
to train the weights always matches the architecture used to load them.
"""

from tensorflow.keras import layers, models, Input

IMG_SIZE = 64
NUM_CLASSES = 4
CLASS_NAMES = ["glioma", "meningioma", "notumor", "pituitary"]
DISPLAY_NAMES = ["Glioma", "Meningioma", "No Tumor", "Pituitary"]


def build_model(img_size: int = IMG_SIZE, num_classes: int = NUM_CLASSES) -> models.Sequential:
    """Build the CNN used for 4-class brain tumor MRI classification.

    3 convolutional blocks (32 -> 64 -> 128 filters), each with two Conv2D
    layers, BatchNormalization, MaxPooling and Dropout, followed by
    GlobalAveragePooling2D and a dense classification head.
    """
    model = models.Sequential([
        Input(shape=(img_size, img_size, 1)),

        # Block 1
        layers.Conv2D(32, (3, 3), activation="relu", padding="same"),
        layers.BatchNormalization(),
        layers.Conv2D(32, (3, 3), activation="relu", padding="same"),
        layers.BatchNormalization(),
        layers.MaxPooling2D((2, 2)),
        layers.Dropout(0.25),

        # Block 2
        layers.Conv2D(64, (3, 3), activation="relu", padding="same"),
        layers.BatchNormalization(),
        layers.Conv2D(64, (3, 3), activation="relu", padding="same"),
        layers.BatchNormalization(),
        layers.MaxPooling2D((2, 2)),
        layers.Dropout(0.25),

        # Block 3
        layers.Conv2D(128, (3, 3), activation="relu", padding="same"),
        layers.BatchNormalization(),
        layers.Conv2D(128, (3, 3), activation="relu", padding="same"),
        layers.BatchNormalization(),
        layers.MaxPooling2D((2, 2)),
        layers.Dropout(0.25),

        # Head
        layers.GlobalAveragePooling2D(),
        layers.Dense(128, activation="relu"),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation="softmax"),
    ])

    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model
